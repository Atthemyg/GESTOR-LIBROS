package gestor.libros.app.controller;

import gestor.libros.app.model.Autor;
import gestor.libros.app.service.AutorService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.Optional;

public class AutoresController {

    @FXML private TableView<Autor>           tablaAutores;
    @FXML private TableColumn<Autor,String>  colNombre;
    @FXML private TableColumn<Autor,String>  colNacionalidad;
    @FXML private TableColumn<Autor,Boolean> colFavorito;

    @FXML private TextField  txtNombre;
    @FXML private TextField  txtNacionalidad;
    @FXML private TextArea   txtBiografia;
    @FXML private CheckBox   chkFavorito;
    @FXML private TextField  txtBuscar;

    @FXML private Button btnGuardar;
    @FXML private Button btnEliminar;
    @FXML private Button btnNuevo;

    private final AutorService autorService = new AutorService();
    private final ObservableList<Autor> datos = FXCollections.observableArrayList();
    private Autor autorSeleccionado = null;

    @FXML
    public void initialize() {
        colNombre      .setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colNacionalidad.setCellValueFactory(new PropertyValueFactory<>("nacionalidad"));
        colFavorito    .setCellValueFactory(new PropertyValueFactory<>("favorito"));

        // Render de la columna favorito como ⭐/—
        colFavorito.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "" : (item ? "⭐" : "—"));
            }
        });

        tablaAutores.setItems(datos);
        cargarAutores();
        btnEliminar.setDisable(true);

        tablaAutores.getSelectionModel().selectedItemProperty().addListener(
                (obs, ant, actual) -> {
                    autorSeleccionado = actual;
                    if (actual != null) {
                        rellenarFormulario(actual);
                        btnEliminar.setDisable(false);
                    } else {
                        limpiarFormulario();
                        btnEliminar.setDisable(true);
                    }
                });
    }

    @FXML
    public void onNuevo() {
        autorSeleccionado = null;
        tablaAutores.getSelectionModel().clearSelection();
        limpiarFormulario();
        txtNombre.requestFocus();
    }

    @FXML
    public void onGuardar() {
        if (txtNombre.getText().isBlank()) {
            new Alert(Alert.AlertType.ERROR, "El nombre es obligatorio.", ButtonType.OK).showAndWait();
            return;
        }

        if (autorSeleccionado == null) {
            Autor nuevo = new Autor(
                    txtNombre.getText().trim(),
                    txtNacionalidad.getText().trim(),
                    txtBiografia.getText().trim(),
                    chkFavorito.isSelected());
            autorService.create(nuevo);
            new Alert(Alert.AlertType.INFORMATION, "Autor guardado.", ButtonType.OK).showAndWait();
        } else {
            autorSeleccionado.setNombre(txtNombre.getText().trim());
            autorSeleccionado.setNacionalidad(txtNacionalidad.getText().trim());
            autorSeleccionado.setBiografia(txtBiografia.getText().trim());
            autorSeleccionado.setFavorito(chkFavorito.isSelected());
            autorService.update(autorSeleccionado);
            new Alert(Alert.AlertType.INFORMATION, "Autor actualizado.", ButtonType.OK).showAndWait();
        }
        cargarAutores();
        limpiarFormulario();
    }

    @FXML
    public void onEliminar() {
        if (autorSeleccionado == null) return;
        Optional<ButtonType> r = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar al autor \"" + autorSeleccionado.getNombre() + "\"?",
                ButtonType.OK, ButtonType.CANCEL).showAndWait();
        if (r.isPresent() && r.get() == ButtonType.OK) {
            autorService.deleteById(autorSeleccionado.getId());
            cargarAutores();
            limpiarFormulario();
            autorSeleccionado = null;
        }
    }

    @FXML
    public void onBuscar() {
        String q = txtBuscar.getText().trim().toLowerCase();
        datos.setAll(autorService.findAll().stream()
                .filter(a -> a.getNombre().toLowerCase().contains(q))
                .toList());
    }

    @FXML
    public void onLimpiarBusqueda() {
        txtBuscar.clear();
        cargarAutores();
    }

    private void cargarAutores() {
        datos.setAll(autorService.findAll());
    }

    private void rellenarFormulario(Autor a) {
        txtNombre.setText(a.getNombre());
        txtNacionalidad.setText(a.getNacionalidad() != null ? a.getNacionalidad() : "");
        txtBiografia.setText(a.getBiografia() != null ? a.getBiografia() : "");
        chkFavorito.setSelected(a.isFavorito());
    }

    private void limpiarFormulario() {
        txtNombre.clear();
        txtNacionalidad.clear();
        txtBiografia.clear();
        chkFavorito.setSelected(false);
    }
}
