package gestor.libros.app.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import gestor.libros.app.model.Autor;
import gestor.libros.app.repository.interfaces.IAutorRepository;
import gestor.libros.database.sqlite.SQLiteConnectionManager;

public class AutorRepository extends SQLiteConnectionManager implements IAutorRepository {

    public AutorRepository() {
        super(rutaDb);
    }

    @Override
    public boolean create(Autor autor) {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "INSERT INTO autores (nombre, nacionalidad, biografia, favorito) VALUES (?, ?, ?, ?)")) {

            sentencia.setString(1, autor.getNombre());
            sentencia.setString(2, autor.getNacionalidad());
            sentencia.setString(3, autor.getBiografia());
            sentencia.setInt(4, autor.isFavorito() ? 1 : 0);

            return sentencia.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("Error creando autor: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Autor findById(Integer id) {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "SELECT * FROM autores WHERE id=?")) {

            sentencia.setInt(1, id);
            ResultSet rs = sentencia.executeQuery();

            if (!rs.next()) return null;

            return new Autor(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("nacionalidad"),
                    rs.getString("biografia"),
                    rs.getInt("favorito") == 1
            );

        } catch (Exception e) {
            System.err.println("Error buscando autor: " + e.getMessage());
            return null;
        }
    }

    @Override
    public List<Autor> findAll() {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "SELECT * FROM autores ORDER BY nombre")) {

            List<Autor> autores = new ArrayList<>();
            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {
                autores.add(new Autor(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("nacionalidad"),
                        rs.getString("biografia"),
                        rs.getInt("favorito") == 1
                ));
            }
            return autores;

        } catch (Exception e) {
            System.err.println("Error listando autores: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public List<Autor> findFavoritos() {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "SELECT * FROM autores WHERE favorito=1 ORDER BY nombre")) {

            List<Autor> autores = new ArrayList<>();
            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {
                autores.add(new Autor(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("nacionalidad"),
                        rs.getString("biografia"),
                        true
                ));
            }
            return autores;

        } catch (Exception e) {
            System.err.println("Error buscando autores favoritos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public boolean update(Autor autor) {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "UPDATE autores SET nombre=?, nacionalidad=?, biografia=?, favorito=? WHERE id=?")) {

            sentencia.setString(1, autor.getNombre());
            sentencia.setString(2, autor.getNacionalidad());
            sentencia.setString(3, autor.getBiografia());
            sentencia.setInt(4, autor.isFavorito() ? 1 : 0);
            sentencia.setInt(5, autor.getId());

            return sentencia.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("Error actualizando autor: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteById(Integer id) {
        try (Connection connection = getConnection();
             PreparedStatement sentencia = connection.prepareStatement(
                     "DELETE FROM autores WHERE id=?")) {

            sentencia.setInt(1, id);
            return sentencia.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("Error eliminando autor: " + e.getMessage());
            return false;
        }
    }
}
