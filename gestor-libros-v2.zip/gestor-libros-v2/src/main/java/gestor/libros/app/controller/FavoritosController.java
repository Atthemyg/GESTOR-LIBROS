package gestor.libros.app.controller;

import gestor.libros.app.model.Autor;
import gestor.libros.app.model.Lectura;
import gestor.libros.app.service.AutorService;
import gestor.libros.app.service.LecturaService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class FavoritosController {

    // ── Tabla libros favoritos ────────────────────────────────────────────────
    @FXML private TableView<Lectura>         tablaLibrosFav;
    @FXML private TableColumn<Lectura,String> colTitulo;
    @FXML private TableColumn<Lectura,String> colEstado;
    @FXML private TableColumn<Lectura,Double> colPuntuacion;

    // ── Tabla autores favoritos ───────────────────────────────────────────────
    @FXML private TableView<Autor>           tablaAutoresFav;
    @FXML private TableColumn<Autor,String>  colNombre;
    @FXML private TableColumn<Autor,String>  colNacionalidad;

    // ── Estadísticas ──────────────────────────────────────────────────────────
    @FXML private Label lblTotalLibros;
    @FXML private Label lblLeidos;
    @FXML private Label lblEnProgreso;
    @FXML private Label lblPendientes;
    @FXML private Label lblMediaPuntuacion;

    private final LecturaService lecturaService = new LecturaService();
    private final AutorService   autorService   = new AutorService();

    @FXML
    public void initialize() {
        // Libros favoritos
        colTitulo    .setCellValueFactory(new PropertyValueFactory<>("libroTitulo"));
        colEstado    .setCellValueFactory(new PropertyValueFactory<>("estado"));
        colPuntuacion.setCellValueFactory(new PropertyValueFactory<>("puntuacion"));
        tablaLibrosFav.setItems(FXCollections.observableArrayList(
                lecturaService.findFavoritos()));

        // Autores favoritos
        colNombre      .setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colNacionalidad.setCellValueFactory(new PropertyValueFactory<>("nacionalidad"));
        tablaAutoresFav.setItems(FXCollections.observableArrayList(
                autorService.findFavoritos()));

        // Estadísticas
        actualizarEstadisticas();
    }

    @FXML
    public void onRefrescar() {
        tablaLibrosFav.setItems(FXCollections.observableArrayList(
                lecturaService.findFavoritos()));
        tablaAutoresFav.setItems(FXCollections.observableArrayList(
                autorService.findFavoritos()));
        actualizarEstadisticas();
    }

    private void actualizarEstadisticas() {
        var todas = lecturaService.findAll();
        long leidos     = todas.stream().filter(l -> "LEIDO"    .equals(l.getEstado())).count();
        long enProgreso = todas.stream().filter(l -> "LEYENDO"  .equals(l.getEstado())).count();
        long pendientes = todas.stream().filter(l -> "PENDIENTE".equals(l.getEstado())).count();

        double media = todas.stream()
                .filter(l -> l.getPuntuacion() != null)
                .mapToDouble(l -> l.getPuntuacion())
                .average()
                .orElse(0);

        lblTotalLibros   .setText(String.valueOf(todas.size()));
        lblLeidos        .setText(String.valueOf(leidos));
        lblEnProgreso    .setText(String.valueOf(enProgreso));
        lblPendientes    .setText(String.valueOf(pendientes));
        lblMediaPuntuacion.setText(String.format("%.1f ⭐", media));
    }
}
