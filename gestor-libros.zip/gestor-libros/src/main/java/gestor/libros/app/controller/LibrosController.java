package gestor.libros.app.controller;

import gestor.libros.app.model.Autor;
import gestor.libros.app.model.Libro;
import gestor.libros.app.service.AutorService;
import gestor.libros.app.service.LibroService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.Optional;

public class LibrosController {

    // ── Tabla ────────────────────────────────────────────────────────────────
    @FXML private TableView<Libro> tablaLibros;
    @FXML private TableColumn<Libro, String>  colTitulo;
    @FXML private TableColumn<Libro, String>  colAutor;
    @FXML private TableColumn<Libro, String>  colGenero;
    @FXML private TableColumn<Libro, Integer> colAnio;
    @FXML private TableColumn<Libro, String>  colIsbn;

    // ── Formulario ───────────────────────────────────────────────────────────
    @FXML private TextField      txtTitulo;
    @FXML private ComboBox<Autor> cmbAutor;
    @FXML private TextField      txtIsbn;
    @FXML private TextField      txtAnio;
    @FXML private TextField      txtGenero;
    @FXML private TextArea       txtSinopsis;
    @FXML private TextField      txtPortadaUrl;
    @FXML private TextField      txtBuscar;

    // ── Botones ──────────────────────────────────────────────────────────────
    @FXML private Button btnGuardar;
    @FXML private Button btnEliminar;
    @FXML private Button btnNuevo;

    // ── Servicios ────────────────────────────────────────────────────────────
    private final LibroService  libroService  = new LibroService();
    private final AutorService  autorService  = new AutorService();

    private final ObservableList<Libro> datos = FXCollections.observableArrayList();
    private Libro libroSeleccionado = null;

    // ─────────────────────────────────────────────────────────────────────────

    @FXML
    public void initialize() {
        configurarColumnas();
        cargarAutores();
        cargarLibros();
        configurarSeleccion();
        btnEliminar.setDisable(true);
    }

    // ── Configuración ─────────────────────────────────────────────────────────

    private void configurarColumnas() {
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colAutor .setCellValueFactory(new PropertyValueFactory<>("autorNombre"));
        colGenero.setCellValueFactory(new PropertyValueFactory<>("genero"));
        colAnio  .setCellValueFactory(new PropertyValueFactory<>("anioPublicacion"));
        colIsbn  .setCellValueFactory(new PropertyValueFactory<>("isbn"));
        tablaLibros.setItems(datos);
    }

    private void cargarAutores() {
        List<Autor> autores = autorService.findAll();
        cmbAutor.setItems(FXCollections.observableArrayList(autores));
    }

    private void cargarLibros() {
        datos.setAll(libroService.findAll());
    }

    private void configurarSeleccion() {
        tablaLibros.getSelectionModel().selectedItemProperty().addListener(
                (obs, anterior, actual) -> {
                    libroSeleccionado = actual;
                    if (actual != null) {
                        rellenarFormulario(actual);
                        btnEliminar.setDisable(false);
                    } else {
                        btnEliminar.setDisable(true);
                    }
                });
    }

    // ── Acciones ──────────────────────────────────────────────────────────────

    @FXML
    public void onNuevo() {
        libroSeleccionado = null;
        limpiarFormulario();
        tablaLibros.getSelectionModel().clearSelection();
        btnEliminar.setDisable(true);
        txtTitulo.requestFocus();
    }

    @FXML
    public void onGuardar() {
        if (!validar()) return;

        Autor autor = cmbAutor.getValue();
        Integer anio = txtAnio.getText().isBlank() ? null
                : Integer.parseInt(txtAnio.getText().trim());

        if (libroSeleccionado == null) {
            // Crear nuevo
            Libro nuevo = new Libro(
                    txtTitulo.getText().trim(),
                    autor != null ? autor.getId() : null,
                    txtIsbn.getText().trim(),
                    anio,
                    txtGenero.getText().trim(),
                    txtSinopsis.getText().trim(),
                    txtPortadaUrl.getText().trim());
            if (libroService.create(nuevo)) {
                mostrarInfo("Libro guardado correctamente.");
                cargarLibros();
                limpiarFormulario();
            }
        } else {
            // Actualizar existente
            libroSeleccionado.setTitulo(txtTitulo.getText().trim());
            libroSeleccionado.setAutorId(autor != null ? autor.getId() : null);
            libroSeleccionado.setIsbn(txtIsbn.getText().trim());
            libroSeleccionado.setAnioPublicacion(anio);
            libroSeleccionado.setGenero(txtGenero.getText().trim());
            libroSeleccionado.setSinopsis(txtSinopsis.getText().trim());
            libroSeleccionado.setPortadaUrl(txtPortadaUrl.getText().trim());
            if (libroService.update(libroSeleccionado)) {
                mostrarInfo("Libro actualizado correctamente.");
                cargarLibros();
            }
        }
    }

    @FXML
    public void onEliminar() {
        if (libroSeleccionado == null) return;

        Optional<ButtonType> resp = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar \"" + libroSeleccionado.getTitulo() + "\"?\n"
                        + "Se eliminarán también sus lecturas, notas y citas.",
                ButtonType.OK, ButtonType.CANCEL).showAndWait();

        if (resp.isPresent() && resp.get() == ButtonType.OK) {
            libroService.deleteById(libroSeleccionado.getId());
            cargarLibros();
            limpiarFormulario();
            libroSeleccionado = null;
        }
    }

    @FXML
    public void onBuscar() {
        String texto = txtBuscar.getText().trim();
        datos.setAll(libroService.findByTitulo(texto));
    }

    @FXML
    public void onLimpiarBusqueda() {
        txtBuscar.clear();
        cargarLibros();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void rellenarFormulario(Libro l) {
        txtTitulo.setText(l.getTitulo());
        txtIsbn.setText(l.getIsbn() != null ? l.getIsbn() : "");
        txtAnio.setText(l.getAnioPublicacion() != null ? String.valueOf(l.getAnioPublicacion()) : "");
        txtGenero.setText(l.getGenero() != null ? l.getGenero() : "");
        txtSinopsis.setText(l.getSinopsis() != null ? l.getSinopsis() : "");
        txtPortadaUrl.setText(l.getPortadaUrl() != null ? l.getPortadaUrl() : "");

        // Seleccionar autor en el ComboBox
        if (l.getAutorId() != null) {
            cmbAutor.getItems().stream()
                    .filter(a -> a.getId().equals(l.getAutorId()))
                    .findFirst()
                    .ifPresent(cmbAutor::setValue);
        } else {
            cmbAutor.setValue(null);
        }
    }

    private void limpiarFormulario() {
        txtTitulo.clear();
        cmbAutor.setValue(null);
        txtIsbn.clear();
        txtAnio.clear();
        txtGenero.clear();
        txtSinopsis.clear();
        txtPortadaUrl.clear();
    }

    private boolean validar() {
        if (txtTitulo.getText().isBlank()) {
            mostrarError("El título es obligatorio.");
            txtTitulo.requestFocus();
            return false;
        }
        String anioStr = txtAnio.getText().trim();
        if (!anioStr.isBlank()) {
            try {
                Integer.parseInt(anioStr);
            } catch (NumberFormatException e) {
                mostrarError("El año debe ser un número entero.");
                txtAnio.requestFocus();
                return false;
            }
        }
        return true;
    }

    private void mostrarError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK).showAndWait();
    }

    private void mostrarInfo(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK).showAndWait();
    }
}
